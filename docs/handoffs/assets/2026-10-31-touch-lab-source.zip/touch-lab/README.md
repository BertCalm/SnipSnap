# Touch Lab

Status: playable browser prototype. Based on SnipSnap `fd76ffa382c1bf94d6a82e5a9484e6cd4140e91c`.
No Android implementation, MPC export change, or listening claim.

The characteristic gesture is **dry rhythm → thumb rises → one accent echoes →
thumb falls while that accent rings**.

Run `python3 -m http.server 4173 --directory prototype/touch-lab` from the repo,
then open `http://localhost:4173`. Tap Start audio. All assets are local; there
are no analytics, external fonts, accounts or data writes in the prototype.
Hosted preview access is handled separately by Sites.

## Interaction

- Eight pads, keyboard Q/W/A/S/Z/X/C/V, and simultaneous pointer input.
- A vertical strip selects four equal-width strike zones. Top is hard, bottom
  soft, like a level fader; the explicit labels matter. The app's existing
  *pad-position* axis is the opposite (`PadHit.velocityAt`: top soft, bottom
  hard). This prototype ignores position within a pad to keep one authority.
- Brightness, Echo and Reverb select a prepared bank. Every trigger snapshots
  the current layer. Subsequent strip or response changes leave it alone.
- Stay retains the position; Return goes to soft on release/cancellation.
- The strip can sit at either edge. Volume dynamics are independent, off by
  default; when enabled, playback gain ranges from 0.3 to 1.0.
- Bass voices choke each other, as do the hats, including their baked tails.
  Other pad tails overlap. Stop sounds/Escape cuts all voices with a short fade.
- Up to 24 non-stopping voices; oldest voice fades if that limit is reached.
  Leaving the tab stops audio so no pad or tail is stranded in the background.

## Sound and architecture

The WAVs are unchanged copies from `testkit/SnipSnap Test Kit`:

| Local asset | Repository source |
| --- | --- |
| kick.wav | A01_Kick.wav |
| snare.wav | A02_Snare.wav |
| hat-closed.wav | A03_HatClosed.wav |
| hat-open.wav | A04_HatOpen.wav |
| clap.wav | A06_Clap.wav |
| tom.wav | A10_TomMid.wav |
| bass-a.wav | A13_BassA.wav |
| bass-d.wav | A14_BassD.wav |

The browser decodes them at the device context rate and prepares 96 mono
buffers: eight pads × three responses × four layers. The processing in
`dsp.mjs` is deliberately an experimental browser effect, not a JS port of
SnipSnap's Kotlin rack. Constants below are design choices awaiting listening.

```text
load WAVs → remove mean / set peak / fade → prepare three four-layer banks
                                                  │
thumb position → layer at pad-down → cached buffer → per-hit gain → output
```

Brightness is a one-pole lowpass at 650, 1800, 4800 and 16000 Hz, capped at
45% of the browser rate. Each result is peak matched to isolate the timbral
change. Echo has four darkening repeats spaced 270 ms apart; the repeat
amplitude falls by 0.52. Reverb uses four damped, strictly lossy combs followed
by two allpasses and a finite two-second tail. Both effects use send levels
0, 0.2, 0.42 and 0.7, with one common headroom factor across the four layers
so stronger tails do not normalize down the dry attack. Tail ends fade to zero.

No work or fetching occurs at note-on beyond selecting the buffer and creating
a playback voice. Preparation yields between pads and keeps the play action
unavailable until the complete bank is ready. The Web Audio compressor guards
the mixed output; DSP stability comes from the fixed finite echoes and lossy
reverb loops, independently of that compressor.

## Verification and limits

Run `node prototype/touch-lab/verify.mjs`. The test reads the actual packaged
24-bit WAVs, checks 96 deterministic, finite, bounded layers, monotonic spectral
brightness on each source, increasing FX tail energy, unchanged first 10 ms of
the dry attack across FX layers, zero-ending tails and the four layer boundaries.
The retained report is `verification.json`.

Headless Chromium interaction checks cover audio initialization, native
simultaneous thumb/pad touches, one trigger per tap, old hits retaining their
layer, Stay/Return, handedness, volume independence, keyboard control, stopping
tails, and responsive layouts at 320/390 portrait, 844 landscape and 1280 desktop.
Phone hardware, Android touch-to-sound latency, Safari and human listening remain
unverified. Browser/device sample-rate conversion can change exact samples.

Potential listening risks: discrete timbral jumps at zone boundaries; a metallic
small-room reverb; brightness matching changing perceived loudness; overlapping
wet accents filling too much space. This first proof has fixed effect times and
global response selection. Continuous modulation of ringing notes is a later,
separate playback feature.

## Path into Android

Verified existing entry points are `shell/.../PadHit.kt` (`velocityAt`, `resolve`),
`app/.../ui/PadGrid.kt` (pointer-down velocity), `app/.../PadEngine.kt` (loads
velocity-layer samples), and `synth/.../Velocity.kt` (current brightness variants).
`NativePads.noteOn` plays rendered buffers; it has no generic reverb-send
argument. The current velocity path falls back to softening an existing sample
when an FX recipe is present. An implementation should extend prepared recipe
layers and supply strip-derived velocity at note-on. Continuous FX control needs
its own playback design. Neither extension is claimed here.

## Why it is built this way

- One strip owns strike strength, freeing the other hand to tap anywhere.
- Cached layers make the expensive work happen before the performance.
- Separate volume dynamics let the player judge tone and space on their own.
- Effects baked into each hit preserve an accent's tail when the thumb returns.
- A browser prototype makes thumb comfort testable before committing to app UI;
  actual phone feel is the principal unanswered question.
