import { clamp, layerFor, LEVELS, RESPONSES, prepareSource, makeLayers } from './dsp.mjs';

const PADS = [
  {id:'A13',name:'Bass A',file:'bass-a.wav',key:'q',color:'#aeb3e4',group:'bass'},
  {id:'A14',name:'Bass D',file:'bass-d.wav',key:'w',color:'#aeb3e4',group:'bass'},
  {id:'A06',name:'Clap',file:'clap.wav',key:'a',color:'#d3a0aa'},
  {id:'A10',name:'Tom',file:'tom.wav',key:'s',color:'#c3a3d2'},
  {id:'A03',name:'Closed hat',file:'hat-closed.wav',key:'z',color:'#96c4b3',group:'hat'},
  {id:'A04',name:'Open hat',file:'hat-open.wav',key:'x',color:'#96c4b3',group:'hat'},
  {id:'A01',name:'Kick',file:'kick.wav',key:'c',color:'#d4ae72'},
  {id:'A02',name:'Snare',file:'snare.wav',key:'v',color:'#d4ae72'}
];
const $ = id => document.getElementById(id);
const state = {strength:.5,response:'brightness',side:'left',release:'stay',dynamics:false,ready:false,hits:0,lastHit:null};
const bank = new Map(), voices = new Set(), flashTimers = new Map();
let ctx, master, compressor, starting = null, stripPointer = null, lastPlayTime = 0;
const padElements = new Map();
for (const pad of PADS) {
  const button = document.createElement('button');
  button.className = 'pad'; button.dataset.pad = pad.id;
  button.style.setProperty('--pad-color',pad.color);
  button.setAttribute('aria-label',`Play ${pad.name} (${pad.key.toUpperCase()})`);
  button.innerHTML = `<span class="pad-top"><span class="pad-id">${pad.id}</span><span class="pad-key">${pad.key.toUpperCase()}</span></span><span class="pad-bottom"><span class="pad-name">${pad.name}</span><span class="pad-meter" aria-hidden="true"><i></i><i></i><i></i><i></i></span></span>`;
  button.addEventListener('pointerdown',event => {
    if (event.pointerType === 'mouse' && event.button !== 0) return;
    event.preventDefault(); play(pad);
  });
  // Native keyboard and assistive-technology activation has detail = 0.
  // Pointer hits already happened on down; their click must not double-hit.
  button.addEventListener('click',event => { if(event.detail === 0) play(pad); });
  $('pads').append(button); padElements.set(pad.id,button);
}
function announce(message) { $('status').textContent = message; }
function setStrength(value) {
  state.strength = clamp(value);
  const percent = Math.round(state.strength * 100), layer = layerFor(state.strength);
  $('strip').style.setProperty('--position',`${percent}%`);
  $('strip').style.setProperty('--value',state.strength);
  $('strip').setAttribute('aria-valuenow',percent);
  $('strip').setAttribute('aria-valuetext',`${LEVELS[layer]}, layer ${layer + 1} of 4`);
  $('strength').textContent = percent;
  $('layer-readout').textContent = `LAYER ${layer + 1} / 4`;
}
function position(event) {
  const rect = strip.querySelector('.strip-track').getBoundingClientRect();
  setStrength(1 - (event.clientY - rect.top) / rect.height);
}
const strip = $('strip');
strip.addEventListener('pointerdown',event => {
  if(stripPointer !== null || (event.pointerType === 'mouse' && event.button !== 0)) return;
  event.preventDefault(); stripPointer = event.pointerId;
  strip.setPointerCapture(event.pointerId); position(event);
});
strip.addEventListener('pointermove',event => { if(event.pointerId === stripPointer) { event.preventDefault(); position(event); } });
function releaseStrip(event) {
  if(event && event.pointerId !== stripPointer) return;
  stripPointer = null;
  if(state.release === 'return') setStrength(0);
}
strip.addEventListener('pointerup',releaseStrip);
strip.addEventListener('pointercancel',releaseStrip);
strip.addEventListener('lostpointercapture',releaseStrip);
strip.addEventListener('keydown',event => {
  const values = {ArrowUp:state.strength+.05,ArrowRight:state.strength+.05,ArrowDown:state.strength-.05,ArrowLeft:state.strength-.05,Home:0,End:1,PageUp:state.strength+.25,PageDown:state.strength-.25};
  if(event.key in values) { event.preventDefault(); setStrength(values[event.key]); }
});
function setResponse(response) {
  if(!RESPONSES.includes(response)) return;
  state.response = response;
  document.querySelectorAll('[data-response]').forEach(button => button.setAttribute('aria-pressed',button.dataset.response === response));
  $('response-description').textContent = {brightness:'Soft → muted. Hard → bright.',echo:'Soft → dry. Hard → four echoes.',space:'Soft → close. Hard → roomy.'}[response];
  $('gesture-hint').textContent = {brightness:'Slide your thumb. Tap with your other hand.',echo:'Raise for an accent. Lower while its echoes ring.',space:'Give one hit a room. Let the next one stay dry.'}[response];
}
document.querySelectorAll('[data-response]').forEach(button => button.addEventListener('click',() => setResponse(button.dataset.response)));
document.querySelectorAll('[data-side]').forEach(button => button.addEventListener('click',() => {
  releaseStrip(); state.side = button.dataset.side;
  $('play-area').classList.toggle('right',state.side === 'right');
  document.querySelectorAll('[data-side]').forEach(b => b.setAttribute('aria-pressed',b.dataset.side === state.side));
}));
document.querySelectorAll('[data-release]').forEach(button => button.addEventListener('click',() => {
  state.release = button.dataset.release;
  document.querySelectorAll('[data-release]').forEach(b => b.setAttribute('aria-pressed',b.dataset.release === state.release));
}));
$('dynamics').addEventListener('change',event => { state.dynamics = event.target.checked; });
$('volume').addEventListener('input',() => {
  if(master && ctx) master.gain.setTargetAtTime(Number($('volume').value)/100 * .65,ctx.currentTime,.01);
});
function toBuffer(data,rate) {
  const buffer = ctx.createBuffer(1,data.length,rate); buffer.copyToChannel(data,0); return buffer;
}
async function initialize() {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if(!AudioContext) throw new Error('This browser cannot play the instrument. Try a current browser.');
  if(!ctx) {
    ctx = new AudioContext({latencyHint:'interactive'});
    master = ctx.createGain(); master.gain.value = Number($('volume').value)/100 * .65;
    compressor = ctx.createDynamicsCompressor();
    // A safety ceiling for stacked pads, not a substitute for bounded FX.
    compressor.threshold.value = -3; compressor.knee.value = 3; compressor.ratio.value = 12;
    compressor.attack.value = .003; compressor.release.value = .12;
    master.connect(compressor); compressor.connect(ctx.destination);
    ctx.addEventListener('statechange',() => {
      if(!state.ready) return;
      const running = ctx.state === 'running';
      $('power').textContent = running ? '● Audio on' : '▶ Resume audio';
      $('power').classList.toggle('running',running);
      $('status-dot').classList.toggle('ready',running);
      if(!running) announce('Audio paused. Tap Resume audio to continue.');
    });
  }
  // Called directly by a user gesture, before loading or other awaits.
  await ctx.resume();
  if(state.ready) { announce('Ready. Every tap captures the strip.'); return; }
  const decoded = await Promise.all(PADS.map(async pad => {
    const response = await fetch(new URL(`assets/${pad.file}`,import.meta.url));
    if(!response.ok) throw new Error(`Could not load ${pad.name}. Check your connection and retry.`);
    const data = await ctx.decodeAudioData(await response.arrayBuffer());
    const mono = new Float32Array(data.length);
    for(let c = 0;c < data.numberOfChannels;c++) {
      const channel = data.getChannelData(c);
      for(let i = 0;i < mono.length;i++) mono[i] += channel[i] / data.numberOfChannels;
    }
    return {pad,rate:data.sampleRate,samples:prepareSource(mono,data.sampleRate)};
  }));
  const pending = new Map();
  for(let i=0;i<decoded.length;i++) {
    const {pad,rate,samples} = decoded[i];
    announce(`Preparing ${i+1} of ${PADS.length} sounds…`);
    const layers = {};
    for(const response of RESPONSES) layers[response] = makeLayers(samples,rate,response).map(data => toBuffer(data,rate));
    pending.set(pad.id,layers);
    // Yield between sounds so the preparation message can paint on a phone.
    await new Promise(resolve => setTimeout(resolve,0));
  }
  bank.clear(); for(const entry of pending) bank.set(...entry);
  state.ready = true; $('status-dot').classList.add('ready');
  announce('Ready. Every tap captures the strip.');
}
$('power').addEventListener('click',() => {
  if(starting) return;
  $('power').disabled = true; $('power').textContent = 'Preparing…';
  starting = initialize().then(() => {
    $('power').textContent = ctx.state === 'running' ? '● Audio on' : '▶ Resume audio';
    $('power').classList.toggle('running',ctx.state === 'running');
    $('status-dot').classList.toggle('ready',ctx.state === 'running');
  }).catch(error => { announce(error.message); $('power').textContent = 'Retry audio'; }).finally(() => {
    starting = null; $('power').disabled = false;
  });
});
function stopVoice(voice) {
  if(voice.stopping) return; voice.stopping = true;
  voice.gain.gain.cancelScheduledValues(ctx.currentTime);
  voice.gain.gain.setTargetAtTime(0,ctx.currentTime,.003);
  voice.source.stop(ctx.currentTime+.02);
}
function stopAll() {
  for(const voice of voices) stopVoice(voice);
  for(const [id,timer] of flashTimers) { clearTimeout(timer); padElements.get(id).classList.remove('hit'); }
  flashTimers.clear();
}
function play(pad) {
  if(!state.ready) { announce('Tap Start audio first.'); return; }
  if(ctx.state !== 'running') { announce('Tap Resume audio first.'); return; }
  const now = performance.now();
  // Capture the gesture at note-on. No future control update touches this voice.
  const strength = state.strength, layer = layerFor(strength), response = state.response;
  const buffer = bank.get(pad.id)[response][layer];
  if(pad.group) for(const voice of voices) if(voice.group === pad.group) stopVoice(voice);
  const alive = [...voices].filter(voice => !voice.stopping);
  if(alive.length >= 24) stopVoice(alive[0]);
  const source = ctx.createBufferSource(), gain = ctx.createGain();
  source.buffer = buffer;
  gain.gain.value = state.dynamics ? .3 + .7 * strength : 1;
  source.connect(gain); gain.connect(master);
  const voice = {source,gain,group:pad.group,stopping:false}; voices.add(voice);
  source.onended = () => { voices.delete(voice); source.disconnect(); gain.disconnect(); };
  source.start();
  const button = padElements.get(pad.id);
  clearTimeout(flashTimers.get(pad.id)); button.classList.add('hit');
  button.querySelectorAll('.pad-meter i').forEach((dot,i) => dot.classList.toggle('on',i<=layer));
  flashTimers.set(pad.id,setTimeout(() => { button.classList.remove('hit'); flashTimers.delete(pad.id); },120));
  state.hits++; state.lastHit = {pad:pad.id,layer,response,strength,gain:gain.gain.value,duration:buffer.duration};
  // Avoid turning the live region into a stream of speech during a fast roll.
  if(now - lastPlayTime > 800) announce(`${pad.name} · ${LEVELS[layer].toLowerCase()} · ${response === 'space' ? 'reverb' : response}`);
  lastPlayTime = now;
}
$('stop').addEventListener('click',() => { stopAll(); if(state.ready) announce('All sounds stopped. Ready for the next hit.'); });
window.addEventListener('keydown',event => {
  if(event.key === 'Escape') { stopAll(); releaseStrip(); return; }
  if(event.repeat || event.ctrlKey || event.metaKey || event.altKey || ['INPUT','TEXTAREA','SELECT'].includes(event.target.tagName)) return;
  const pad = PADS.find(pad => pad.key === event.key.toLowerCase());
  if(pad) { event.preventDefault(); play(pad); }
});
window.addEventListener('blur',() => { releaseStrip(); stopAll(); });
document.addEventListener('visibilitychange',() => { if(document.hidden) { releaseStrip(); stopAll(); } });
setStrength(.5);
// Read-only diagnostics for QA, never used to drive the audio path.
window.__touchLab = {snapshot:() => ({...state,lastHit:state.lastHit && {...state.lastHit},voices:voices.size,audioState:ctx?.state,preparedBuffers:bank.size*RESPONSES.length*4})};
