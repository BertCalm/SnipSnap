// Browser interaction proof, not a port of the Android effects rack.
// Every effect is prepared once. A hit only selects a cached sample.
export const RESPONSES = ['brightness', 'echo', 'space'];
export const LEVELS = ['Soft', 'Medium', 'Firm', 'Hard'];
export function clamp(value, lo = 0, hi = 1) { return Number.isFinite(value) ? Math.min(hi, Math.max(lo, value)) : lo; }
export function layerFor(strength) { return Math.min(3, Math.floor(clamp(strength) * 4)); }
export function peak(samples) { let p = 0; for (const s of samples) p = Math.max(p, Math.abs(s)); return p; }
export function prepareSource(samples, rate) {
  const out = Float32Array.from(samples);
  let mean = 0; for (const s of out) mean += s; mean /= out.length;
  for (let i = 0; i < out.length; i++) out[i] -= mean;
  const p = peak(out); if (p > 0) for (let i = 0; i < out.length; i++) out[i] *= .65 / p;
  fadeEnd(out, rate);
  return out;
}
function fadeEnd(data, rate) {
  const frames = Math.min(data.length, Math.round(.008 * rate));
  for (let i = 0; i < frames; i++) data[data.length - frames + i] *= 1 - i / Math.max(1, frames - 1);
}
function lowpass(samples, rate, cutoff) {
  const output = new Float32Array(samples.length);
  const a = 1 - Math.exp(-2 * Math.PI * cutoff / rate);
  let state = 0;
  for (let i = 0; i < samples.length; i++) { state += a * (samples[i] - state); output[i] = state; }
  return output;
}
function roomTail(source, rate) {
  const length = source.length + Math.round(2.0 * rate);
  const wet = new Float32Array(length);
  // Four lossy delay loops scatter the attack. Gains < 1 bound each loop;
  // a damping filter removes brightness on each trip. No feedback limiter.
  for (const [seconds, feedback] of [[.0297,.73],[.0371,.76],[.0411,.71],[.0437,.74]]) {
    const delay = new Float32Array(Math.round(seconds * rate));
    let head = 0, damped = 0;
    for (let i = 0; i < length; i++) {
      const y = delay[head];
      damped += .24 * (y - damped);
      delay[head] = (i < source.length ? source[i] : 0) + feedback * damped;
      wet[i] += y * .25;
      head = (head + 1) % delay.length;
    }
  }
  // Short allpasses make separated returns more diffuse without raising
  // the frequency response. The finite tail is faded, never hard-cut.
  for (const seconds of [.005,.0017]) {
    const delay = new Float32Array(Math.round(seconds * rate));
    let head = 0;
    for (let i = 0; i < length; i++) {
      const x = wet[i], d = delay[head], y = d - .5 * x;
      delay[head] = x + .5 * y; wet[i] = y;
      head = (head + 1) % delay.length;
    }
  }
  fadeEnd(wet, rate);
  return wet;
}
export function makeLayers(source, rate, response) {
  if (!RESPONSES.includes(response)) throw new Error(`Unknown response: ${response}`);
  if (response === 'brightness') {
    return [650,1800,4800,16000].map(cutoff => {
      const out = lowpass(source, rate, Math.min(cutoff, rate * .45));
      // Timbre comparisons should not collapse into a volume comparison.
      const gain = peak(out) > 1e-9 ? peak(source) / peak(out) : 1;
      for (let i = 0; i < out.length; i++) out[i] *= gain;
      fadeEnd(out, rate); return out;
    });
  }
  const wet = response === 'space' ? roomTail(source, rate) : (() => {
    const hop = Math.round(.27 * rate);
    const out = new Float32Array(source.length + 4 * hop);
    let repeat = source;
    for (let n = 1; n <= 4; n++) {
      repeat = lowpass(repeat, rate, 4200);
      const level = Math.pow(.52, n - 1);
      for (let i = 0; i < repeat.length; i++) out[i + n * hop] += repeat[i] * level;
    }
    return out;
  })();
  return [0,.2,.42,.7].map(send => {
    const out = new Float32Array(send === 0 ? source.length : wet.length);
    for (let i = 0; i < out.length; i++) out[i] = (source[i] || 0) + send * (wet[i] || 0);
    // One fixed headroom factor for all FX layers preserves the dry attack.
    // Per-layer normalization would make the hard layer's attack duck.
    for (let i = 0; i < out.length; i++) out[i] *= .72;
    fadeEnd(out, rate); return out;
  });
}
