// Run: node prototype/touch-lab/verify.mjs
// Measures the actual packaged WAVs through the browser prototype's DSP.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {clamp,layerFor,prepareSource,makeLayers,peak,RESPONSES} from './dsp.mjs';
function readWav(file) {
  const b=readFileSync(new URL(`assets/${file}.wav`,import.meta.url));
  assert.equal(b.toString('ascii',0,4),'RIFF');
  let rate,channels,bits,format,data;
  for(let offset=12;offset+8<=b.length;) {
    const id=b.toString('ascii',offset,offset+4),length=b.readUInt32LE(offset+4),start=offset+8;
    if(id==='fmt ') {format=b.readUInt16LE(start);channels=b.readUInt16LE(start+2);rate=b.readUInt32LE(start+4);bits=b.readUInt16LE(start+14);}
    if(id==='data') data=b.subarray(start,start+length);
    offset=start+length+(length%2);
  }
  assert.equal(format,1);assert.ok(bits===16||bits===24);assert.equal(channels,1);
  const bytes=bits/8;
  return {rate,samples:Float32Array.from({length:data.length/bytes},(_,i)=>data.readIntLE(i*bytes,bytes)/2**(bits-1))};
}
function energy(a,start=0,end=a.length) {let sum=0;for(let i=start;i<end;i++)sum+=a[i]*a[i];return sum;}
function brightness(a) {let difference=0;for(let i=1;i<a.length;i++)difference+=(a[i]-a[i-1])**2;return difference/energy(a);}
const files=['kick','snare','hat-closed','hat-open','clap','tom','bass-a','bass-d'];
const report={environment:'Node Float32 DSP harness; not Android or a listening judgement',samples:8,layers:0,maxPeak:0,maxDc:0,checks:[],perPad:{}};
assert.deepEqual([0,.249,.25,.499,.5,.749,.75,1].map(layerFor),[0,0,1,1,2,2,3,3]);
assert.equal(clamp(NaN),0);assert.equal(layerFor(-1),0);assert.equal(layerFor(2),3);
for(const file of files) {
  const wav=readWav(file),source=prepareSource(wav.samples,wav.rate);
  const start=performance.now();
  for(const response of RESPONSES) {
    const layers=makeLayers(source,wav.rate,response);
    assert.deepEqual(layers,makeLayers(source,wav.rate,response),'deterministic layers');
    for(const layer of layers) {
      assert.ok(layer.every(Number.isFinite));assert.ok(peak(layer)<=1,`${file}/${response}: peak ceiling`);
      assert.ok(layer.at(-1)===0,'tail ends at zero');
      const dc=Math.abs(layer.reduce((a,b)=>a+b,0)/layer.length);
      assert.ok(dc<.01,`${file}/${response}: DC bound`);
      report.maxPeak=Math.max(report.maxPeak,peak(layer));report.maxDc=Math.max(report.maxDc,dc);report.layers++;
    }
    if(response==='brightness') {
      const b=layers.map(brightness);
      assert.ok(b.every((v,i)=>i===0||v>b[i-1]),`${file}: brightness increases at every layer`);
      assert.ok(layers.every(l=>Math.abs(peak(l)-peak(source))<.001),'brightness is peak matched');
    } else {
      // Reverb/echo strength adds a tail without silently turning down the attack.
      const attack=Math.round(.01*wav.rate);
      assert.deepEqual(layers[0].slice(0,attack),layers[3].slice(0,attack),'dry attack unchanged');
      const tail=layers.map(layer=>energy(layer,source.length));
      assert.equal(tail[0],0);assert.ok(tail.every((v,i)=>i===0||v>tail[i-1]),`${file}/${response}: wet tail increases`);
    }
  }
  report.perPad[file]={validationMs:Number((performance.now()-start).toFixed(2)),sourceSeconds:source.length/wav.rate};
}
report.checks=['four reachable zones, including exact boundaries','96 finite, bounded, deterministic layers','brightness rises monotonically on all eight sounds','FX tails grow without ducking the first 10 ms of the dry attack','all tails end at zero; DC below 0.01'];
console.log(JSON.stringify(report,null,2));
