# Nacre handoff source and evidence

Prepared 2026-11-07. Application implementation: 60efe061f96446eae1557cdd8c35ac567dd84afb,
merged through PR #885 as 08d5ff8cabeb3c3409ccb92c36c89dda2f54ce8e.
Authoritative published Site source: 6537de55f13dd458121e688260bce9f96491ba59.

This is a small recovery bundle, not a standalone playable Site or an MPC bank.
No WAVs, APKs, original kit ZIP, compiled classes, classpaths, Git metadata or credentials
are included. Fetch the complete existing Site through Sites using the project_id in
site/.openai/hosting.json to recover the hosted audio and source history. Do not create
a replacement Site. The original bank ZIP and the live study manifest also identify the
audio files and hashes. They require the owner's existing Site access.

- site/: deployed HTML/config, study recipes, render harnesses, measurements and checksum lists.
- ui/: final comparison-page template; deployed site/dist/index.html is authoritative.
- tools/: retained historical builder and mock-media DOM checks.
- validation/: actual feature-gate, artifact, publication, preservation and CI evidence.

The retained builders/analyzer/DOM scripts contain this session's /workspace paths and
JSDOM dependency path. Remap those before running them elsewhere. No one-command portable
rebuild is claimed. The Java probes call an internal Kotlin diagnostic method at the
recorded commit; verify its current signature and construct a fresh classpath first.

The asset builder alone does not create final HTML. Preserve the deployed HTML, or replace
the template's single __COMPARE_DATA__ placeholder with compact JSON from contrast/manifest.json,
escaping '<' as '\u003c'. The deployed version also has measurement/checksum footer links and
scroll-margin styling. Refresh comparison checksums after edits. Full native WAVs remain
unchanged; quick sequences use 1.2-second excerpts with a six-millisecond end fade and
250-millisecond gaps; full sequences use six-second files and 750-millisecond gaps.

Seven November 7 studies are measured, not accepted or promoted into the bank. The last user
feedback was that differences were hard to tell. The factory source and downloadable bank
were not changed by the comparison-page revision. Read the accompanying handoff Markdown
before implementing or promoting an articulation change.
