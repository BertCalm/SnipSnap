const fs=require('fs'),assert=require('assert');
const {JSDOM}=require('/workspace/scratch/nacre-page-check/node_modules/jsdom');
const template=fs.readFileSync('/workspace/scratch/nacre-contrast-page/index.template.html','utf8');
function set(key,label,labels){
 const items=labels.map((label,i)=>({id:'item-'+i,label,sample:'contrast/'+key+'-'+i+'.wav',recipe:'contrast/'+key+'-'+i+'.json'}));
 const sequence=(suffix,length,gap)=>({sample:'contrast/'+key+'-'+suffix+'.wav',duration:items.length*length+(items.length-1)*gap,segments:items.map((item,i)=>({id:item.id,label:item.label,start:i*(length+gap),end:i*(length+gap)+length}))});
 return {key,label,items,quickSequence:sequence('quick',1.2,.25),fullSequence:sequence('full',6,.75)};
}
const data={bank:{layers:[set('pearl','Pearl Close',['Soft','Medium','Hard']),set('coral','Coral Reply',['Soft','Medium','Hard']),set('kelp','Kelp Passage',['Soft','Medium','Hard'])],presets:set('presets','Preset characters',['Pearl Close','Coral Reply','Kelp Passage'])},contact:set('contact','Wider contact',['Gentle','Accepted reference','Firmer','Full contact']),returns:set('returns','Stronger returns',['Minimum returns','Coral strong','Kelp strong'])};
assert.equal(template.split('__COMPARE_DATA__').length,2);
const calls={play:[],pause:0},state={rejectNext:null,deferNext:false,rejectDeferred:null};
const dom=new JSDOM(template.replace('__COMPARE_DATA__',JSON.stringify(data).replaceAll('<','\\u003c')),{runScripts:'dangerously',url:'https://nacre-native-touch.bertcalm.chatgpt.site/',beforeParse(w){
 const p=w.HTMLMediaElement.prototype;
 Object.defineProperty(p,'paused',{get(){return this.qaPaused??true},configurable:true});
 Object.defineProperty(p,'ended',{get(){return this.qaEnded??false},configurable:true});
 p.pause=function(){calls.pause++;this.qaPaused=true;this.dispatchEvent(new w.Event('pause'))};
 p.load=function(){this.qaPaused=true;this.qaEnded=false};
 p.play=function(){calls.play.push(this.getAttribute('src'));this.qaEnded=false;if(state.rejectNext){const e=state.rejectNext;state.rejectNext=null;this.qaPaused=true;return Promise.reject(e)}this.qaPaused=false;this.dispatchEvent(new w.Event('play'));if(state.deferNext){state.deferNext=false;return new Promise((resolve,reject)=>{state.rejectDeferred=reject})}return Promise.resolve()};
}});
const d=dom.window.document,$=id=>d.getElementById(id),player=$('player');
const event=name=>new dom.window.Event(name),button=(group,id)=>d.querySelector('[data-group="'+group+'"][data-item-id="item-'+id+'"]');
function click(group,id){button(group,id).click();}
function at(time){player.currentTime=time;player.dispatchEvent(event('timeupdate'));}
async function flush(){await new Promise(resolve=>setImmediate(resolve));}
(async()=>{
 assert.equal(d.querySelectorAll('audio').length,1);assert.equal(calls.play.length,0);assert.equal(player.volume,.7);assert.equal($('error').hidden,true);
 click('bank',0);assert.equal(calls.play.at(-1),data.bank.layers[0].items[0].sample);assert.equal(player.paused,false);assert.equal(player.currentTime,0);assert.equal(button('bank',0).getAttribute('aria-pressed'),'true');
 at(2);click('bank',2);assert.equal(calls.play.at(-1),data.bank.layers[0].items[2].sample);assert.equal(player.currentTime,0);assert.equal(button('bank',0).getAttribute('aria-pressed'),'false');
 $('volume').value='.4';$('volume').dispatchEvent(event('input'));assert.equal(player.volume,.4);assert.equal($('volume-value').textContent,'40%');click('contact',2);assert.equal(player.volume,.4);assert.equal(calls.play.at(-1),data.contact.items[2].sample);
 $('stop').click();assert.equal(player.paused,true);assert.equal(player.currentTime,0);assert.equal(d.querySelectorAll('[data-item-id][aria-pressed="true"]').length,0);assert($('playing').textContent.startsWith('Stopped'));await player.play();assert($('playing').textContent.includes('Firmer'));assert($('playing').textContent.startsWith('Playing:'));assert.equal(button('contact',2).getAttribute('aria-pressed'),'true');$('stop').click();
 const before=calls.play.length;$('bank-preset').value='coral';$('bank-preset').dispatchEvent(event('change'));assert.equal(calls.play.length,before);click('bank',1);assert.equal(calls.play.at(-1),data.bank.layers[1].items[1].sample);
 $('bank-mode').value='presets';$('bank-mode').dispatchEvent(event('change'));assert.equal($('preset-wrap').hidden,true);assert.equal(player.paused,true);assert.equal(player.getAttribute('src'),null);assert.equal($('bank-items').querySelectorAll('button').length,3);assert.equal($('bank-compare').textContent,'Compare presets');
 $('bank-compare').click();assert.equal(calls.play.at(-1),data.bank.presets.quickSequence.sample);at(1.3);assert($('playing').textContent.includes('brief gap'));assert.equal(d.querySelectorAll('[data-item-id][aria-pressed="true"]').length,0);at(1.6);assert($('playing').textContent.includes('Coral Reply'));assert.equal(button('bank',1).getAttribute('aria-pressed'),'true');
 player.pause();assert($('playing').textContent.startsWith('Paused:'));await player.play();assert($('playing').textContent.startsWith('Playing:'));
 $('full-tails').checked=true;$('bank-compare').click();assert.equal(calls.play.at(-1),data.bank.presets.fullSequence.sample);at(6.1);assert($('playing').textContent.includes('brief gap'));at(6.9);assert($('playing').textContent.includes('Coral Reply'));
 $('contact-compare').click();assert.equal(calls.play.at(-1),data.contact.fullSequence.sample);at(13.5);assert($('playing').textContent.includes('Firmer'));assert.equal(button('contact',2).getAttribute('aria-pressed'),'true');
 player.qaEnded=true;player.qaPaused=true;player.dispatchEvent(event('ended'));assert($('playing').textContent.startsWith('Finished:'));player.dispatchEvent(event('timeupdate'));assert($('playing').textContent.startsWith('Finished:'));assert.equal(d.querySelectorAll('[data-item-id][aria-pressed="true"]').length,0);
 $('full-tails').checked=false;$('returns-compare').click();assert.equal(calls.play.at(-1),data.returns.quickSequence.sample);at(1.5);assert($('playing').textContent.includes('Coral strong'));
 state.rejectNext={name:'NotAllowedError'};click('contact',0);await flush();assert.equal($('error').hidden,false);assert($('error').textContent.includes('Play button'));$('stop').click();assert.equal($('error').hidden,true);
 state.deferNext=true;click('bank',0);const rejectOld=state.rejectDeferred;click('bank',2);rejectOld({name:'NotSupportedError'});await flush();assert.equal($('error').hidden,true);assert.equal(calls.play.at(-1),data.bank.presets.items[2].sample);
 player.dispatchEvent(event('error'));assert.equal($('error').hidden,false);click('returns',0);assert.equal($('error').hidden,true);assert.equal(calls.play.at(-1),data.returns.items[0].sample);assert.equal(player.volume,.4);
 $('bank-mode').value='layers';$('bank-mode').dispatchEvent(event('change'));assert.equal($('preset-wrap').hidden,false);assert.equal(player.paused,false);assert.equal(calls.play.at(-1),data.returns.items[0].sample);
 console.log(JSON.stringify({result:'PASS',audioElements:1,autoplayAtLoad:false,individualPlayAndRestart:'pass',monitorAndStop:'pass',bankModesAndPresetChoice:'pass',quickAndFullSequenceChoice:'pass',segmentAndGapLabels:'pass',endedAndPauseLabels:'pass',playPromiseErrorsAndStaleRejection:'pass',media:'mocked; no real browser/audio playback'}));dom.window.close();
})().catch(e=>{console.error(e);dom.window.close();process.exitCode=1});
