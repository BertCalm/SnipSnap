from pathlib import Path
import re

original = Path('/workspace/scratch/nacre-native-touch-original-index-b4e.html').read_text()
html = original.replace('<title>Nacre · Native velocity layers</title>', '<title>Nacre · All sixteen pads</title>')
html = html.replace('<header><p class="eyebrow">', '<header><p><a href="index.html">Back to the C3 comparisons</a></p><p class="eyebrow">', 1)
html = re.sub(r'(data-zone="[012]"[^>]*>)(Soft|Medium|Hard)(</button>)', r'\1Play \2\3', html)
html = html.replace('>Checksums</a>', '>Original kit archive checksums</a>')
html = html.replace('<main class="grid"', '<p id="playback-error" role="alert"></p><main class="grid"', 1)
start = html.index('];const midi=')
html = html[:start] + """
];
const midi=document.getElementById('midi'),value=document.getElementById('midi-value'),volume=document.getElementById('volume'),volumeValue=document.getElementById('volume-value');
const cards=[...document.querySelectorAll('article[data-slot]')],audios=[...document.querySelectorAll('audio')],error=document.getElementById('playback-error');
function solo(active){for(const a of audios)if(a!==active&&(!a.paused||a.currentTime!==0)){a.pause();a.currentTime=0;}}
function play(a){solo(a);error.textContent='';const result=a.play();if(result&&result.catch)result.catch(()=>{error.textContent='Playback could not start. Use the audio player’s Play control.';});}
function select(card,zone,startPlayback=false){
  const pad=pads.find(p=>p.slot===Number(card.dataset.slot)),layer=pad.layers[zone],audio=card.querySelector('audio');
  const changed=audio.getAttribute('src')!==layer.sample,wasPlaying=!audio.paused;
  if(changed){audio.pause();audio.src=layer.sample;audio.currentTime=0;}
  if(startPlayback)audio.currentTime=0;
  card.querySelector('.layer-status').textContent=layer.name+' · MIDI '+layer.velocityStart+'–'+layer.velocityEnd;
  card.querySelector('[data-wave]').href=layer.sample;card.querySelector('[data-replay]').href=layer.recipe;
  card.querySelectorAll('[data-zone]').forEach(b=>b.setAttribute('aria-pressed',String(Number(b.dataset.zone)===zone)));
  if(startPlayback||(changed&&wasPlaying))play(audio);
}
function setVelocity(){const v=Number(midi.value),zone=pads[0].layers.findIndex(l=>v>=l.velocityStart&&v<=l.velocityEnd);value.textContent=v+' · '+pads[0].layers[zone].name;cards.forEach(c=>select(c,zone));}
function setVolume(){const v=Number(volume.value);audios.forEach(a=>a.volume=v);volumeValue.textContent=Math.round(v*100)+'%';}
for(const card of cards)for(const button of card.querySelectorAll('[data-zone]'))button.addEventListener('click',()=>select(card,Number(button.dataset.zone),true));
for(const a of audios)a.addEventListener('play',()=>solo(a));
midi.addEventListener('input',setVelocity);volume.addEventListener('input',setVolume);
document.getElementById('stop').addEventListener('click',()=>audios.forEach(a=>{a.pause();a.currentTime=0;}));
setVolume();
})();</script></html>
"""
Path('/workspace/sites/nacre-native-touch/dist/bank.html').write_text(html)
print('Full bank view now plays a selected layer, solos playback, and leaves same-zone slider changes uninterrupted.')
