from pathlib import Path
import json, shutil, hashlib, wave
import numpy as np

root = Path('/workspace/sites/nacre-native-touch/dist')
study = Path('/workspace/scratch/nacre-wide-contact-study')
out = root / 'contrast'
out.mkdir(exist_ok=True)
for name in ['listening', 'native', 'recipes', 'returns']:
    shutil.copytree(study / name, out / name, dirs_exist_ok=True)
for name in ['report.json', 'study-manifest.json', 'review.json']:
    shutil.copy2(study / name, out / name)
(out / 'source').mkdir(exist_ok=True)
for name in ['NacreWideContactProbe.java', 'NacreReturnContrastProbe.java', 'analyze.py']:
    shutil.copy2(study / name, out / 'source' / name)

old_index = root / 'index.html'
backup = Path('/workspace/scratch/nacre-native-touch-original-index-b4e.html')
if not backup.exists():
    assert hashlib.sha256(old_index.read_bytes()).hexdigest() == '4f7089c91141eb772b946d4f265786f02f69f9eadeb2451d5135e643e802f007'
    shutil.copy2(old_index, backup)

RATE = 44100
def read_pcm(path):
    with wave.open(str(path), 'rb') as w:
        assert (w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()) == (1, 3, RATE, 264600), path
        raw = w.readframes(w.getnframes())
    b = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
    x = b[:, 0].astype(np.int32) | (b[:, 1].astype(np.int32) << 8) | (b[:, 2].astype(np.int32) << 16)
    x = (x ^ 0x800000) - 0x800000
    assert x[-1] == 0, path
    return x

def encode(x):
    z = x.astype(np.int32)
    assert np.max(np.abs(z.astype(np.int64))) < 8388608
    return np.stack((z & 255, (z >> 8) & 255, (z >> 16) & 255), axis=1).astype(np.uint8).tobytes()

audio_records = []
def sequence(key, items, profile):
    seconds, gap, fade = (1.2, .25, .006) if profile == 'quick' else (6., .75, 0.)
    n, ngap, nfade = round(seconds * RATE), round(gap * RATE), round(fade * RATE)
    chunks, segments, cursor = [], [], 0
    for i, item in enumerate(items):
        x = read_pcm(root / item['sample'])[:n].copy()
        if nfade:
            x[-nfade:] = np.rint(x[-nfade:].astype(np.float64) * np.linspace(1., 0., nfade)).astype(np.int32)
        assert x[0] == 0 and x[-1] == 0
        segments.append({'id': item['id'], 'label': item['label'], 'start': cursor / RATE, 'end': (cursor + len(x)) / RATE})
        chunks.append(x); cursor += len(x)
        if i < len(items) - 1:
            chunks.append(np.zeros(ngap, dtype=np.int32)); cursor += ngap
    combined = np.concatenate(chunks)
    sample = 'contrast/sequences/' + key + '-' + profile + '.wav'
    p = root / sample; p.parent.mkdir(exist_ok=True)
    with wave.open(str(p), 'wb') as w:
        w.setparams((1, 3, RATE, 0, 'NONE', 'not compressed')); w.writeframes(encode(combined))
    result = {'sample': sample, 'duration': len(combined) / RATE, 'segments': segments,
              'excerptSeconds': seconds, 'gapSeconds': gap, 'presentationEndFadeSeconds': fade,
              'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
    audio_records.append({'sample': sample, 'frames': len(combined), 'peak': float(np.max(np.abs(combined.astype(np.int64))) / 8388608),
                          'dc': float(np.mean(combined) / 8388608), 'lastSample': int(combined[-1]), 'sha256': result['sha256']})
    return result

def make_set(key, label, items):
    return {'key': key, 'label': label, 'items': items,
            'quickSequence': sequence(key, items, 'quick'), 'fullSequence': sequence(key, items, 'full')}

manifest = json.loads((root / 'manifest.json').read_text())
pads = [p for p in manifest['pads'] if p['pitchMidi'] == 48]
assert [p['slot'] for p in pads] == [1, 9, 13]
layers = []
for pad in pads:
    key = pad['preset'].lower().replace(' ', '-')
    items = [{'id': key + '-' + l['name'].lower(), 'label': l['name'], 'sample': l['sample'], 'recipe': l['recipe'],
              'sha256': l['sampleSha256']} for l in pad['layers']]
    layers.append(make_set('layers-' + key, pad['preset'], items))
preset_items = [{'id': 'preset-' + p['preset'].lower().replace(' ', '-'), 'label': p['preset'], 'sample': p['layers'][-1]['sample'],
                 'recipe': p['layers'][-1]['recipe'], 'sha256': p['layers'][-1]['sampleSha256']} for p in pads]

report = json.loads((study / 'report.json').read_text())
contact_labels = ['Gentle contact', 'Accepted reference', 'Firmer contact', 'Full contact']
contact_items = []
for label, row in zip(contact_labels, report['contact'], strict=True):
    key = Path(row['sampleFile']).stem.split('-')[-1]
    contact_items.append({'id': 'contact-' + key, 'label': label, 'sample': 'contrast/' + row['sampleFile'],
                          'recipe': 'contrast/' + row['wrapperFile'], 'sha256': row['sampleSha256']})
return_labels = ['Minimum returns', 'Strong coral', 'Strong kelp']
return_items = [{'id': 'returns-' + row['name'], 'label': label, 'sample': 'contrast/' + row['sampleFile'],
                 'recipe': 'contrast/' + row['wrapperFile'], 'sha256': row['sampleSha256']}
                for label, row in zip(return_labels, report['returns'], strict=True)]

config = {'schemaVersion': 1, 'createdUtc': '2026-11-07',
          'bank': {'layers': layers, 'presets': make_set('current-presets', 'Current preset characters', preset_items)},
          'contact': make_set('wide-contact', 'Wider contact study', contact_items),
          'returns': make_set('strong-returns', 'Stronger return study', return_items),
          'source': {'bankRevision': manifest['source']['revision'], 'studyRenderRevision': report['sourceCommit'],
                     'referenceSha256': report['referenceHardC3Hash'], 'sameNote': 'C3', 'midi': 48, 'seed': '7',
                     'engineChanges': False, 'bankChanged': False, 'studiesIncludedInKit': False},
          'presentation': {'individualFiles': 'Full six-second PCM24 sources, unchanged',
                           'quickComparisons': 'First 1.2 seconds of each source, with only a six-millisecond excerpt-end fade and 250-millisecond gaps',
                           'fullComparisons': 'Full six-second files with 750-millisecond gaps',
                           'gain': 'One common browser monitor volume; no output RMS/peak matching',
                           'limits': 'Actual Kotlin renders and decoded PCM measurements; not heard. Browser playback remains unverified here.'}}
for item in [i for group in layers + [config['bank']['presets'], config['contact'], config['returns']] for i in group['items']]:
    assert hashlib.sha256((root / item['sample']).read_bytes()).hexdigest() == item['sha256']
assert contact_items[1]['sha256'] == pads[0]['layers'][-1]['sampleSha256']
(out / 'manifest.json').write_text(json.dumps(config, indent=2) + '\n')
(out / 'sequence-qa.json').write_text(json.dumps(audio_records, indent=2) + '\n')
Path('/workspace/scratch/nacre-contrast-config.json').write_text(json.dumps(config, indent=2) + '\n')
print(json.dumps({'sets': len(layers) + 3, 'sequenceFiles': len(audio_records), 'studyChoices': 7,
                  'maxSequencePeak': max(r['peak'] for r in audio_records), 'maxAbsSequenceDc': max(abs(r['dc']) for r in audio_records)}))
