# SPARK R3 portable contrast player

Frozen handoff reference, 2026-11-07. Josh has completed this check: Attack,
Metallic ring and Brightness were all **Clearly different**. Keep R3 DSP and
its control ranges as the working baseline. This package is not a request for
another listening round. The prior six fine recipe comparisons all received
“They sound the same”; no favorite recipes or factory presets were selected.

## Run locally

Extract this ZIP into a new directory, then run from that directory:

```sh
python3 -m http.server 8080 --bind 127.0.0.1 --directory dist
```

Open http://127.0.0.1:8080/. Serve at the HTTP root; opening index.html with
file:// does not support its absolute asset paths and manifest fetch. There is
no build step or dependency installation.

The current three-pair flow, copyable summary, settings export and all 12 WAVs
are included. Browser choices are local to the origin; a new local origin has
no saved answers. Optional historical-page links open the original owner-private
Site and may require its owner to sign in. The current task itself is local.

## Provenance and scope

- Canonical Site source commit: e960c197a942d28dfbb3a3a0928a4ff46d148d52.
- Site: https://snipsnap-spark-audition.bertcalm.chatgpt.site
- JavaScript, CSS, contrast manifest and all WAVs are byte-for-byte copies.
- Only the portable HTML's optional history links were changed to absolute
  hosted URLs. Source and bundled checksums are in SOURCE.json.
- The unchanged manifest records the study's creation-time status and the
  earlier failed fine study. The November 7 listening decision above supersedes
  that pending-status text; no DSP or audio was changed for the handoff.
- CHECKSUMS.sha256 covers every payload file except itself.
- No Git metadata, credentials, hosting identity, scratch files, or full
  historical audio collection is included. Do not use this as a complete
  replacement for the live Site.

Read the companion Markdown handoff for app code, commit/PR references,
validation limits and the reproduction warning about newer unrelated changes
to Thump.kt and Dsp.kt.
